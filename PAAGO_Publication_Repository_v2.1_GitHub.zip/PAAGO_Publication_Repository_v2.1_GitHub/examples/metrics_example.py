from evaluation.metrics import compute_metrics

if __name__ == "__main__":
    y = [0, 0, 1, 1]
    p = [0.05, 0.30, 0.72, 0.91]
    print(compute_metrics(y, p, threshold=0.5))
