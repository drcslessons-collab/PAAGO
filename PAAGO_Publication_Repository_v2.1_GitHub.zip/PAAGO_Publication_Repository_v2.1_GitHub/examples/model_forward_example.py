"""Minimal PAAGO forward-pass example."""
import sys
from pathlib import Path

import torch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models import EEGFPN


def main() -> None:
    model = EEGFPN(channels=21, samples=2560, num_classes=2)
    model.eval()
    x = torch.randn(2, 21, 2560)
    with torch.no_grad():
        out = model(x, return_attention=True)
    print("logits:", tuple(out["logits"].shape))
    print("risk:", tuple(out["risk"].shape))
    print("adjacency:", tuple(out["adjacency"].shape))
    print("node_attention:", tuple(out["node_attention"].shape))


if __name__ == "__main__":
    main()
