"""Metric utilities for PAAGO experiments."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
    average_precision_score,
)


def _safe_auc(y_true, y_prob, fn):
    try:
        if len(np.unique(y_true)) < 2:
            return float("nan")
        return float(fn(y_true, y_prob))
    except Exception:
        return float("nan")


def _best_threshold(y_true, y_prob, min_sensitivity=0.0, metric="f1"):
    thresholds = np.linspace(0.01, 0.99, 99)
    best_t, best_score = 0.5, -1.0
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob).astype(float)
    for t in thresholds:
        pred = (y_prob >= t).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
        sensitivity = tp / (tp + fn) if (tp + fn) else 0.0
        specificity = tn / (tn + fp) if (tn + fp) else 0.0
        if sensitivity < min_sensitivity:
            continue
        if metric == "f2":
            beta2 = 4.0
            precision = tp / (tp + fp) if (tp + fp) else 0.0
            score = (1 + beta2) * precision * sensitivity / (beta2 * precision + sensitivity) if (precision + sensitivity) else 0.0
        elif metric == "balanced_accuracy":
            score = 0.5 * (sensitivity + specificity)
        else:
            score = f1_score(y_true, pred, zero_division=0)
        if score > best_score:
            best_t, best_score = float(t), float(score)
    return best_t


def compute_metrics(y_true, y_prob, threshold=0.5, optimize_threshold=False, min_sensitivity=0.0, threshold_metric="f1"):
    """Compute binary classification metrics using PAAGO output probabilities."""
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.nan_to_num(np.asarray(y_prob).astype(float), nan=0.0, posinf=1.0, neginf=0.0).clip(0.0, 1.0)
    if optimize_threshold:
        threshold = _best_threshold(y_true, y_prob, min_sensitivity=min_sensitivity, metric=threshold_metric)
    y_pred = (y_prob >= float(threshold)).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) else 0.0
    specificity = tn / (tn + fp) if (tn + fp) else 0.0
    return {
        "threshold": float(threshold),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "sensitivity": float(sensitivity),
        "specificity": float(specificity),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "mcc": float(matthews_corrcoef(y_true, y_pred)) if len(np.unique(y_pred)) > 1 else 0.0,
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": _safe_auc(y_true, y_prob, roc_auc_score),
        "pr_auc": _safe_auc(y_true, y_prob, average_precision_score),
        "tp": int(tp), "tn": int(tn), "fp": int(fp), "fn": int(fn),
    }
