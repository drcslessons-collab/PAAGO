# Paper files

Place the final manuscript files here before public release:

```text
PAAGO_Manuscript.docx
PAAGO_Manuscript.tex
PAAGO_Manuscript.pdf
Supplementary_Material.pdf
```

The current package includes a BibTeX template only.
