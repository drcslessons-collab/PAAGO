# Experiment map

| Experiment | Main config pattern | Purpose |
|---|---|---|
| exp1_ce_baseline | `v62_exp1_ce_baseline_seed*.yaml` | Cross-entropy baseline |
| exp2_focal_fixed | `v62_exp2_focal_fixed_seed*.yaml` | Fixed focal-loss configuration |
| exp3_adaptive_gamma | `v62_exp3_adaptive_gamma_seed*.yaml` | Adaptive focal gamma |
| exp4_adaptive_gamma_ema | `v62_exp4_adaptive_gamma_ema_seed*.yaml` | Adaptive focal gamma with EMA |
| exp5_full_sensitivity | `v62_exp5_full_sensitivity_seed*.yaml` | Full sensitivity-oriented setup |
