# PAAGO Model Architecture

PAAGO is implemented as `models.EEGFPN`, an EEG seizure-prediction network that combines temporal feature extraction, dynamic graph learning, cross-attention fusion, transformer-based contextual encoding, and attention pooling.

## Main components

1. **AdaptiveTemporalEncoder**: converts each EEG channel into an embedding using multi-kernel temporal convolutions and squeeze-excitation recalibration.
2. **DynamicGraphLearning**: learns channel-to-channel relations using multi-head attention with optional top-k sparsification.
3. **CrossAttentionFusion**: fuses temporal tokens with graph-enhanced tokens.
4. **TransformerContextEncoder**: models contextual interactions among EEG channels.
5. **AttentionPooling**: aggregates channel tokens into a patient/window-level representation.
6. **Classifier and risk heads**: produce class logits and a continuous risk score.

## Expected input and output

Input tensor shape:

```python
(batch_size, channels, samples)
```

Default configuration:

```python
channels=21
samples=2560
num_classes=2
embed_dim=128
```

Output dictionary:

```python
{
    "logits": Tensor[batch_size, num_classes],
    "risk": Tensor[batch_size]
}
```

When `return_attention=True`, the model also returns:

```python
{
    "adjacency": Tensor[batch_size, channels, channels],
    "cross_attention": Tensor[batch_size, channels, channels],
    "node_attention": Tensor[batch_size, channels]
}
```

## Minimal inference example

```python
import torch
from models import EEGFPN

model = EEGFPN(channels=21, samples=2560, num_classes=2)
x = torch.randn(2, 21, 2560)
out = model(x, return_attention=True)
print(out["logits"].shape, out["risk"].shape)
```
