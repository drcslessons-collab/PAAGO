# PAAGO Large Artifact Release Assets

This GitHub Edition intentionally excludes large artifacts that should not be committed to Git.

## Excluded artifacts

- `runs/` full per-seed experiment folders
- model checkpoints: `*.pt`, `*.pth`, `*.ckpt`
- raw EEG data and cached EEG windows
- compressed archives

## Recommended storage

For publication, upload large reproducibility artifacts to one of the following:

1. **Zenodo** for a citable DOI.
2. **GitHub Releases** for versioned assets.
3. **Institutional repository** if required by the university or journal.
4. **Google Drive/OneDrive** only as a temporary sharing option.

## Suggested release structure

```text
PAAGO_v2.1_release_assets/
├── runs/
├── checkpoints/
├── figures/
├── logs/
└── README_RELEASE_ASSETS.md
```

After uploading, update the main `README.md` with the final DOI or download link.
