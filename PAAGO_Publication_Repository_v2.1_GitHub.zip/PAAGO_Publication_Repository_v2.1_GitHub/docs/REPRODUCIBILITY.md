# Reproducibility notes

## Included artifacts

- Five v62 experiment configurations across seeds 42, 123, and 2026.
- Per-run metrics, training histories, figures, and checkpoint files under `runs/`.
- Aggregated ablation summaries under `outputs/`.
- Patient split audit outputs under `outputs/v61_patient_audit_*`.

## Required before full rerun

1. Add the final model source file under `models/`.
2. Rebuild the cached CHB-MIT data under `data/EEG_FPN_Cache_v4/`.
3. Confirm that the manifest is patient-independent and has no split overlap.
4. Run the same seed-specific configs.

## Recommended reporting

Report mean ± standard deviation across the three seeds. For ablations, use `outputs/v62_ablation_stats.csv` for Wilcoxon comparisons against the baseline.
