import torch, numpy as np
from tqdm import tqdm
from evaluation.metrics import compute_metrics


class StableFocalLoss(torch.nn.Module):
    """Numerically stable focal loss for two-class logits.

    Uses log_softmax in float32 and optional class weights. This avoids NaN/Inf
    issues that can occur with weighted CE inside mixed precision.
    """
    def __init__(self, weight=None, gamma=1.5, eps=1e-6):
        super().__init__()
        self.register_buffer('weight', weight.detach().clone() if isinstance(weight, torch.Tensor) else None)
        self.gamma = float(gamma)
        self.eps = float(eps)

    def forward(self, logits, target):
        logits = torch.nan_to_num(logits.float(), nan=0.0, posinf=30.0, neginf=-30.0)
        target = target.long()
        logp = torch.nn.functional.log_softmax(logits, dim=1)
        logpt = logp.gather(1, target.view(-1, 1)).squeeze(1).clamp(min=np.log(self.eps), max=0.0)
        pt = logpt.exp().clamp(min=self.eps, max=1.0 - self.eps)
        loss = -((1.0 - pt) ** self.gamma) * logpt
        if self.weight is not None:
            w = self.weight.to(logits.device).float().clamp(min=0.0, max=100.0)
            loss = loss * w[target]
        loss = torch.nan_to_num(loss, nan=0.0, posinf=100.0, neginf=0.0)
        return loss.mean()


def _make_cls_loss(loss_type, pos_weight=None, focal_gamma=1.5):
    loss_type = str(loss_type or 'cross_entropy').lower()
    if loss_type in ['focal', 'focal_loss', 'stable_focal']:
        return StableFocalLoss(weight=pos_weight, gamma=focal_gamma)
    return torch.nn.CrossEntropyLoss(weight=pos_weight)


def run_epoch(model, loader, optimizer, device, scaler=None, train=True, lambda_cls=1.0,
              lambda_risk=0.1, pos_weight=None, batch_callback=None, threshold=0.5,
              loss_type='stable_focal', focal_gamma=1.5, optimize_threshold=False,
              min_sensitivity=0.0, threshold_metric='f1', max_grad_norm=0.5,
              skip_nonfinite=True, ema=None):
    model.train(train); losses=[]; ys=[]; probs=[]; skipped=0
    cls_loss = _make_cls_loss(loss_type, pos_weight=pos_weight, focal_gamma=focal_gamma)
    mse=torch.nn.SmoothL1Loss(beta=0.5)
    total_batches = len(loader) if hasattr(loader, '__len__') else None
    for batch_idx, batch in enumerate(tqdm(loader, leave=False), start=1):
        x=batch['x'].to(device, non_blocking=True).float()
        y=batch['y'].to(device, non_blocking=True).long()
        risk=batch['risk'].to(device, non_blocking=True).float()
        x = torch.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
        risk = torch.nan_to_num(risk, nan=0.0, posinf=1.0, neginf=0.0).clamp(0.0, 1.0)
        if train: optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(train):
            with torch.cuda.amp.autocast(enabled=(scaler is not None)):
                out=model(x)
                logits = torch.nan_to_num(out['logits'], nan=0.0, posinf=30.0, neginf=-30.0)
                risk_pred = torch.nan_to_num(out['risk'], nan=0.0, posinf=1.0, neginf=0.0).float().clamp(0.0, 1.0)
                loss=lambda_cls*cls_loss(logits,y)+lambda_risk*mse(risk_pred,risk)
            if not torch.isfinite(loss):
                skipped += 1
                if batch_idx <= 5 or skipped % 10 == 0:
                    print(f'[warning] non-finite loss skipped at batch {batch_idx}: {loss.detach().cpu().item()}', flush=True)
                if train:
                    optimizer.zero_grad(set_to_none=True)
                continue
            if train:
                if scaler:
                    scaler.scale(loss).backward()
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), float(max_grad_norm))
                    scaler.step(optimizer); scaler.update()
                    if ema is not None: ema.update(model)
                else:
                    loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), float(max_grad_norm)); optimizer.step()
                    if ema is not None: ema.update(model)
        losses.append(float(loss.detach().cpu()))
        with torch.no_grad():
            p=torch.softmax(logits.detach().float(),dim=1)[:,1].cpu().numpy()
            p=np.nan_to_num(p, nan=0.0, posinf=1.0, neginf=0.0).clip(0.0,1.0)
        probs.extend(p.tolist()); ys.extend(y.detach().cpu().numpy().tolist())
        if batch_callback is not None:
            batch_callback(batch_idx, total_batches)
    m=compute_metrics(
        ys, probs, threshold=threshold, optimize_threshold=optimize_threshold,
        min_sensitivity=min_sensitivity, threshold_metric=threshold_metric
    )
    m['loss']=float(np.mean(losses)) if losses else float('nan')
    m['skipped_batches']=int(skipped)
    return m, ys, probs
