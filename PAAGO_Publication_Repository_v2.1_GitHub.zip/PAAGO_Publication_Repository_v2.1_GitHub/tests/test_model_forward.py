import torch
from models import EEGFPN


def test_eegfpn_forward_shapes():
    model = EEGFPN(channels=21, samples=2560, num_classes=2, embed_dim=64, temporal_channels=16)
    x = torch.randn(2, 21, 2560)
    out = model(x, return_attention=True)
    assert out["logits"].shape == (2, 2)
    assert out["risk"].shape == (2,)
    assert out["adjacency"].shape == (2, 21, 21)
    assert out["node_attention"].shape == (2, 21)
