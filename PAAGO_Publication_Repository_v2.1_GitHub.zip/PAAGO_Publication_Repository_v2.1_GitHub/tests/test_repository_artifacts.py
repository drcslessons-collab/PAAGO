from pathlib import Path


def test_core_artifacts_exist():
    root = Path(__file__).resolve().parents[1]
    assert (root / "configs").exists()
    assert (root / "outputs" / "v62_ablation_summary.csv").exists()
    assert (root / "trainer" / "engine.py").exists()
