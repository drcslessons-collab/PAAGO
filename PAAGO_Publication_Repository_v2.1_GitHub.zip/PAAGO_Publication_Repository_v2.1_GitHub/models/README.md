# Models

The supplied archives did not include the final PAAGO/EEG-FPN model source file referenced by `scripts/smoke_test.py`:

```python
from models.eeg_fpn import EEGFPN
```

Before using this repository for full training or checkpoint reloading, add the final model implementation here, for example:

```text
models/eeg_fpn.py
models/__init__.py
```

The repository already includes configurations, training engine logic, metric utilities, results, and checkpoints from the uploaded experiment package.
