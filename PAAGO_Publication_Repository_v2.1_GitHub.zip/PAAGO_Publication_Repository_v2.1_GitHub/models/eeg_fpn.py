from torch import nn
from .adaptive_temporal_encoder import AdaptiveTemporalEncoder
from .dynamic_graph_learning import DynamicGraphLearning
from .cross_attention_fusion import CrossAttentionFusion
from .transformer_encoder import TransformerContextEncoder
from .attention_pooling import AttentionPooling
class EEGFPN(nn.Module):
    def __init__(self, channels=21, samples=2560, num_classes=2, embed_dim=128, temporal_channels=32, graph_heads=4, cross_heads=4, transformer_heads=4, transformer_layers=2, graph_topk=6, dropout=0.1):
        super().__init__(); self.temporal=AdaptiveTemporalEncoder(channels,temporal_channels,embed_dim,dropout=dropout)
        self.graph=DynamicGraphLearning(embed_dim,graph_heads,graph_topk,dropout)
        self.fusion=CrossAttentionFusion(embed_dim,cross_heads,dropout)
        self.context=TransformerContextEncoder(channels,embed_dim,transformer_heads,transformer_layers,dropout)
        self.pool=AttentionPooling(embed_dim)
        self.classifier=nn.Sequential(nn.LayerNorm(embed_dim),nn.Linear(embed_dim,embed_dim//2),nn.GELU(),nn.Dropout(dropout),nn.Linear(embed_dim//2,num_classes))
        self.risk=nn.Sequential(nn.LayerNorm(embed_dim),nn.Linear(embed_dim,embed_dim//2),nn.GELU(),nn.Linear(embed_dim//2,1),nn.Sigmoid())
    def forward(self,x, return_attention=False):
        t=self.temporal(x); g,adj=self.graph(t,True); f,cross=self.fusion(t,g,True); z=self.context(f); pooled,node_w=self.pool(z)
        out={'logits':self.classifier(pooled),'risk':self.risk(pooled).squeeze(-1)}
        if return_attention: out.update({'adjacency':adj,'cross_attention':cross,'node_attention':node_w})
        return out
