from torch import nn
class CrossAttentionFusion(nn.Module):
    def __init__(self, dim=128, heads=4, dropout=0.1):
        super().__init__(); self.attn=nn.MultiheadAttention(dim,heads,dropout=dropout,batch_first=True)
        self.n1=nn.LayerNorm(dim); self.ff=nn.Sequential(nn.Linear(dim,dim*4),nn.GELU(),nn.Dropout(dropout),nn.Linear(dim*4,dim)); self.n2=nn.LayerNorm(dim)
    def forward(self,t,g, need_weights=False):
        y,w=self.attn(t,g,g,need_weights=True,average_attn_weights=False)
        z=self.n1(t+y); z=self.n2(z+self.ff(z)); return (z,w.mean(1)) if need_weights else z
