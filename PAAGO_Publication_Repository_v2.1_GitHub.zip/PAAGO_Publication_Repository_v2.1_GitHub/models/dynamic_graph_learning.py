import torch
from torch import nn
import math
class DynamicGraphLearning(nn.Module):
    def __init__(self, dim=128, heads=4, topk=6, dropout=0.1):
        super().__init__(); assert dim%heads==0
        self.dim=dim; self.heads=heads; self.d=dim//heads; self.topk=topk
        self.q=nn.Linear(dim,dim); self.k=nn.Linear(dim,dim); self.v=nn.Linear(dim,dim); self.o=nn.Linear(dim,dim)
        self.norm=nn.LayerNorm(dim); self.drop=nn.Dropout(dropout)
    def forward(self,x, return_attention=False):
        b,n,d=x.shape
        q=self.q(x).view(b,n,self.heads,self.d).transpose(1,2); k=self.k(x).view(b,n,self.heads,self.d).transpose(1,2); v=self.v(x).view(b,n,self.heads,self.d).transpose(1,2)
        s=torch.matmul(q,k.transpose(-2,-1))/math.sqrt(self.d)
        if self.topk and self.topk<n:
            vals,idx=torch.topk(s,self.topk,dim=-1); mask=torch.full_like(s,float('-inf')); s=mask.scatter(-1,idx,vals)
        a=torch.softmax(s,dim=-1); h=torch.matmul(a,v).transpose(1,2).contiguous().view(b,n,d)
        out=self.norm(x+self.drop(self.o(h)))
        adj=a.mean(1)
        return (out,adj) if return_attention else out
