from torch import nn
import torch
class AttentionPooling(nn.Module):
    def __init__(self, dim): super().__init__(); self.score=nn.Linear(dim,1)
    def forward(self,x):
        w=torch.softmax(self.score(x).squeeze(-1),dim=-1); return (x*w.unsqueeze(-1)).sum(1), w
