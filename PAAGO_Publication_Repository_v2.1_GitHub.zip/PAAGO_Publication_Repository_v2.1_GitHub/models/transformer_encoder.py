from torch import nn
import torch
class TransformerContextEncoder(nn.Module):
    def __init__(self, seq_len=21, dim=128, heads=4, layers=2, dropout=0.1):
        super().__init__(); self.pos=nn.Parameter(torch.zeros(1,seq_len,dim)); nn.init.normal_(self.pos,std=0.02)
        enc=nn.TransformerEncoderLayer(d_model=dim,nhead=heads,dim_feedforward=dim*4,dropout=dropout,batch_first=True,norm_first=True,activation='gelu')
        self.encoder=nn.TransformerEncoder(enc,num_layers=layers)
    def forward(self,x): return self.encoder(x+self.pos[:,:x.size(1)])
