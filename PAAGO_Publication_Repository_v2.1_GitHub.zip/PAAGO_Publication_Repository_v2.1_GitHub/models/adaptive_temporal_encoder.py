import torch
from torch import nn

class SEBlock(nn.Module):
    def __init__(self, dim, reduction=8):
        super().__init__(); self.net=nn.Sequential(nn.Linear(dim,dim//reduction),nn.ReLU(),nn.Linear(dim//reduction,dim),nn.Sigmoid())
    def forward(self,x):
        # x: B*C,F,T
        w=x.mean(-1); w=self.net(w).unsqueeze(-1); return x*w
class AdaptiveTemporalEncoder(nn.Module):
    def __init__(self, channels=21, temporal_channels=32, embed_dim=128, kernels=(3,7,15,31), dropout=0.1):
        super().__init__(); self.channels=channels
        self.proj=nn.Sequential(nn.Conv1d(1,temporal_channels,7,padding=3),nn.BatchNorm1d(temporal_channels),nn.GELU())
        self.branches=nn.ModuleList([nn.Sequential(nn.Conv1d(temporal_channels,temporal_channels,k,padding=k//2),nn.BatchNorm1d(temporal_channels),nn.GELU()) for k in kernels])
        self.bottle=nn.Sequential(nn.Conv1d(temporal_channels*len(kernels),embed_dim,1),nn.BatchNorm1d(embed_dim),nn.GELU())
        self.se=SEBlock(embed_dim)
        self.res=nn.Sequential(nn.Conv1d(embed_dim,embed_dim,3,padding=1),nn.BatchNorm1d(embed_dim),nn.GELU(),nn.Dropout(dropout),nn.Conv1d(embed_dim,embed_dim,3,padding=1),nn.BatchNorm1d(embed_dim))
        self.pool=nn.AdaptiveAvgPool1d(1)
    def forward(self,x):
        b,c,t=x.shape; z=x.reshape(b*c,1,t); z=self.proj(z)
        z=torch.cat([br(z) for br in self.branches],dim=1); z=self.bottle(z); z=self.se(z); z=torch.relu(z+self.res(z))
        z=self.pool(z).squeeze(-1).reshape(b,c,-1); return z
