# Data

Raw EEG data are not redistributed here. Use the CHB-MIT Scalp EEG Database from PhysioNet and create the cached dataset expected by the PAAGO configuration files.

Expected local cache path:

```text
data/EEG_FPN_Cache_v4/
```

Expected manifest file:

```text
data/EEG_FPN_Cache_v4/manifest_patient.csv
```

The v61 audit reports in `outputs/` can be used to verify patient split integrity and class balance.
