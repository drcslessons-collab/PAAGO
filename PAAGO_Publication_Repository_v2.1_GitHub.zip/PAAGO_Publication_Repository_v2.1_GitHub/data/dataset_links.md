# Dataset links

- CHB-MIT Scalp EEG Database: https://physionet.org/content/chbmit/
- PhysioNet credentialed access and citation instructions should be followed according to the dataset provider.

Do not commit raw EEG recordings or restricted data to this repository.
