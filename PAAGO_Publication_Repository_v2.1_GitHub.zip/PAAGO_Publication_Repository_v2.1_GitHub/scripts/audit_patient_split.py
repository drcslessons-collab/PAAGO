import argparse, json, re
from pathlib import Path
import pandas as pd


def infer_patient(row):
    for col in ['patient', 'subject', 'patient_id']:
        if col in row and pd.notna(row[col]) and str(row[col]).strip():
            return str(row[col]).strip()
    text = ' '.join(str(row.get(c, '')) for c in ['edf_path','chunk_file'])
    m = re.search(r'(chb\d{2})', text, flags=re.I)
    return m.group(1).lower() if m else 'unknown'


def main():
    ap = argparse.ArgumentParser(description='Audit patient-level leakage across train/val/test splits.')
    ap.add_argument('--cache-dir', required=True)
    ap.add_argument('--manifest-name', default='manifest.csv')
    ap.add_argument('--out-dir', default='outputs/patient_audit')
    args = ap.parse_args()

    cache = Path(args.cache_dir)
    manifest = Path(args.manifest_name)
    if not manifest.is_absolute():
        manifest = cache / args.manifest_name
    if not manifest.exists():
        raise FileNotFoundError(f'Manifest not found: {manifest}')

    df = pd.read_csv(manifest)
    if 'patient' not in df.columns:
        df['patient'] = df.apply(infer_patient, axis=1)
    else:
        df['patient'] = df.apply(infer_patient, axis=1)

    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    summary = (df.groupby(['split','patient'])
                 .agg(windows=('label','size'), positives=('label','sum'))
                 .reset_index())
    summary['negatives'] = summary['windows'] - summary['positives']
    summary.to_csv(out_dir/'patient_split_counts.csv', index=False)

    split_patients = {s: set(g['patient'].astype(str)) for s,g in summary.groupby('split')}
    overlaps = []
    splits = sorted(split_patients)
    for i,a in enumerate(splits):
        for b in splits[i+1:]:
            inter = sorted(split_patients[a] & split_patients[b])
            overlaps.append({'split_a':a, 'split_b':b, 'overlap_count':len(inter), 'overlap_patients': ','.join(inter)})
    overlap_df = pd.DataFrame(overlaps)
    overlap_df.to_csv(out_dir/'patient_split_overlap.csv', index=False)

    class_summary = df.groupby('split').agg(windows=('label','size'), positives=('label','sum')).reset_index()
    class_summary['negatives'] = class_summary['windows'] - class_summary['positives']
    class_summary['positive_rate'] = class_summary['positives'] / class_summary['windows'].clip(lower=1)
    class_summary.to_csv(out_dir/'split_class_summary.csv', index=False)

    report = {
        'manifest': str(manifest),
        'rows': int(len(df)),
        'patients_by_split': {k: sorted(v) for k,v in split_patients.items()},
        'overlaps': overlaps,
        'patient_leakage_detected': any(x['overlap_count'] > 0 for x in overlaps),
    }
    (out_dir/'patient_audit_report.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    print(f'Saved audit to: {out_dir}')

if __name__ == '__main__':
    main()
