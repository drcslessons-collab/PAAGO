import argparse, os, shutil, subprocess, sys, time
from pathlib import Path

def run(cmd):
    print('+', ' '.join(cmd), flush=True)
    subprocess.check_call(cmd)

def main():
    ap = argparse.ArgumentParser(description='Copy CHB-MIT sharded cache from Drive to local scratch for fast training.')
    ap.add_argument('--src', default='/content/drive/MyDrive/EEG_FPN_Cache/chbmit_cache')
    ap.add_argument('--dst', default='/content/local-scratch/chbmit_cache_fast')
    ap.add_argument('--clean', action='store_true')
    args = ap.parse_args()
    src, dst = Path(args.src), Path(args.dst)
    if not (src/'manifest.csv').exists():
        raise FileNotFoundError(f'Missing manifest: {src}/manifest.csv')
    if args.clean and dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True, exist_ok=True)
    t0=time.time()
    # rsync is faster/incremental when available; fallback to copytree.
    try:
        run(['rsync','-a','--info=progress2', str(src) + '/', str(dst) + '/'])
    except Exception:
        print('rsync failed/not available; falling back to shutil.copytree', flush=True)
        shutil.copytree(src, dst, dirs_exist_ok=True)
    print(f'done in {(time.time()-t0)/60:.1f} min')
    print('dst:', dst)
    print('files:', sum(1 for _ in dst.rglob('*') if _.is_file()))
    print('manifest:', dst/'manifest.csv')

if __name__ == '__main__':
    main()
