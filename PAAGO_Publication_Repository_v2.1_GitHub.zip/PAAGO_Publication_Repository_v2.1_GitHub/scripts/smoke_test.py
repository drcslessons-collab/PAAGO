import torch
from models.eeg_fpn import EEGFPN
m=EEGFPN(channels=21,samples=2560,num_classes=2,embed_dim=64,temporal_channels=16,graph_heads=2,cross_heads=2,transformer_heads=2,transformer_layers=1,graph_topk=4)
x=torch.randn(2,21,2560)
out=m(x,return_attention=True)
print('logits',out['logits'].shape,'risk',out['risk'].shape,'adj',out['adjacency'].shape,'cross',out['cross_attention'].shape)
