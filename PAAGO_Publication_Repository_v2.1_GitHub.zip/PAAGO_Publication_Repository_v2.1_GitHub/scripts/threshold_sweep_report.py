import argparse, json, csv
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from datasets.cached_dataset import CHBMITCachedDataset
from models.eeg_fpn import EEGFPN
from trainer.engine import run_epoch
from evaluation.metrics import _metrics_at_threshold, find_best_threshold


def evaluate_probs(checkpoint, split, batch_size=None, manifest_name=None):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ck = torch.load(checkpoint, map_location=device)
    cfg = ck['cfg']
    ds = CHBMITCachedDataset(cfg.get('cache_dir','data/EEG_FPN_Cache_v4'), split, sort_by_chunk=True, manifest_name=(manifest_name or cfg.get('manifest_name','manifest.csv')))
    bs = int(batch_size or cfg.get('batch_size', 8 if device.type=='cpu' else 128))
    dl = DataLoader(ds, batch_size=bs, shuffle=False, num_workers=0 if device.type=='cpu' else int(cfg.get('num_workers',2)), pin_memory=(device.type=='cuda'))
    model = EEGFPN(cfg['channels'], cfg['samples'], cfg['num_classes'], **cfg['model']).to(device)
    model.load_state_dict(ck['model'])
    if cfg.get('use_ema', False) and ck.get('ema') and ck['ema'].get('shadow'):
        with torch.no_grad():
            for name, param in model.named_parameters():
                if name in ck['ema']['shadow']:
                    param.data.copy_(ck['ema']['shadow'][name].to(device))
        print('[ema] using EMA weights')
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
    _, y, p = run_epoch(model, dl, opt, device, None, False, cfg.get('lambda_cls',1.0), cfg.get('lambda_risk',0.1), None,
                        threshold=0.5, loss_type=cfg.get('loss_type','stable_focal'), focal_gamma=cfg.get('focal_gamma',1.5))
    return np.asarray(y).astype(int), np.asarray(p).astype(float), ck


def main():
    ap = argparse.ArgumentParser(description='Threshold sweep report for a saved checkpoint.')
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--split', default='val')
    ap.add_argument('--out-dir', default='outputs/threshold_sweep')
    ap.add_argument('--manifest-name', default=None)
    ap.add_argument('--batch-size', type=int, default=None)
    ap.add_argument('--min-sensitivity', type=float, default=0.0)
    args = ap.parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    y, p, ck = evaluate_probs(args.checkpoint, args.split, args.batch_size, args.manifest_name)

    thresholds = np.unique(np.concatenate([np.linspace(0.001,0.5,200), np.linspace(0.51,0.99,49), np.quantile(p, np.linspace(0.01,0.99,99))]))
    rows = []
    for t in thresholds:
        m = _metrics_at_threshold(y, p, float(t))
        rows.append(m)
    csv_path = out_dir / f'{args.split}_threshold_sweep.csv'
    with open(csv_path, 'w', newline='') as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader(); wr.writerows(rows)

    t_f1, m_f1 = find_best_threshold(y, p, min_sensitivity=0.0, metric='f1')
    t_f2, m_f2 = find_best_threshold(y, p, min_sensitivity=args.min_sensitivity, metric='f2')
    report = {'split': args.split, 'checkpoint': args.checkpoint, 'best_f1': m_f1, 'best_f2': m_f2, 'min_sensitivity_for_f2': args.min_sensitivity}
    json_path = out_dir / f'{args.split}_threshold_report.json'
    json_path.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    print('saved:', csv_path, json_path)

if __name__ == '__main__':
    main()
