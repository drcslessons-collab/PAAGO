import argparse, json, torch
from pathlib import Path
from torch.utils.data import DataLoader
from datasets.cached_dataset import CHBMITCachedDataset
from models.eeg_fpn import EEGFPN
from trainer.engine import run_epoch
from evaluation.metrics import find_best_threshold, compute_metrics


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--split', default='val')
    ap.add_argument('--min-sensitivity', type=float, default=0.5)
    ap.add_argument('--metric', default='f1')
    ap.add_argument('--out', default=None)
    ap.add_argument('--manifest-name', default=None)
    args = ap.parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ck = torch.load(args.checkpoint, map_location=device)
    cfg = ck['cfg']
    ds = CHBMITCachedDataset(cfg.get('cache_dir','data/EEG_FPN_Cache_v4'), args.split, sort_by_chunk=True, manifest_name=(args.manifest_name or cfg.get('manifest_name','manifest.csv')))
    batch_size = int(cfg.get('batch_size', 8 if device.type=='cpu' else 128))
    dl = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=0 if device.type=='cpu' else 2, pin_memory=(device.type=='cuda'))
    model = EEGFPN(cfg['channels'], cfg['samples'], cfg['num_classes'], **cfg['model']).to(device)
    model.load_state_dict(ck['model'])
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
    _, y, p = run_epoch(model, dl, opt, device, None, False, cfg.get('lambda_cls',1.0), cfg.get('lambda_risk',0.1), None,
                        threshold=0.5, loss_type=cfg.get('loss_type','stable_focal'), focal_gamma=cfg.get('focal_gamma',1.5))
    t, m = find_best_threshold(y, p, min_sensitivity=args.min_sensitivity, metric=args.metric)
    m['selected_threshold'] = t
    out = Path(args.out) if args.out else Path(cfg.get('out_dir','runs/calibration')) / f'threshold_{args.split}.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(m, indent=2))
    print(json.dumps(m, indent=2))
    print('saved:', out)

if __name__ == '__main__':
    main()
