import argparse, json, re
from pathlib import Path
import pandas as pd


def infer_patient_from_row(row):
    if 'patient' in row and pd.notna(row['patient']) and str(row['patient']).strip():
        return str(row['patient']).strip()
    text = ' '.join(str(row.get(c, '')) for c in ['edf_path','chunk_file'])
    m = re.search(r'(chb\d{2})', text, flags=re.I)
    return m.group(1).lower() if m else 'unknown'


def parse_list(s):
    return {x.strip() for x in str(s or '').split(',') if x.strip()}


def main():
    ap = argparse.ArgumentParser(description='Create a patient-disjoint manifest without rewriting NPZ chunks.')
    ap.add_argument('--cache-dir', required=True)
    ap.add_argument('--source-manifest', default='manifest.csv')
    ap.add_argument('--out-manifest', default='manifest_patient.csv')
    ap.add_argument('--val-patients', default='chb06,chb07,chb08,chb09')
    ap.add_argument('--test-patients', default='chb20,chb21,chb22,chb23,chb24')
    args = ap.parse_args()

    cache = Path(args.cache_dir)
    src = Path(args.source_manifest)
    if not src.is_absolute(): src = cache / args.source_manifest
    out = Path(args.out_manifest)
    if not out.is_absolute(): out = cache / args.out_manifest
    if not src.exists(): raise FileNotFoundError(f'Source manifest not found: {src}')

    df = pd.read_csv(src)
    df['patient'] = df.apply(infer_patient_from_row, axis=1)
    val = parse_list(args.val_patients); test = parse_list(args.test_patients)
    if val & test:
        raise ValueError(f'val and test patient overlap: {sorted(val & test)}')

    def assign(p):
        if p in test: return 'test'
        if p in val: return 'val'
        return 'train'
    df['split'] = df['patient'].apply(assign)
    df.to_csv(out, index=False)

    summary = df.groupby('split').agg(windows=('label','size'), positives=('label','sum')).reset_index()
    summary['negatives'] = summary['windows'] - summary['positives']
    summary['positive_rate'] = summary['positives'] / summary['windows'].clip(lower=1)
    meta = {'out_manifest': str(out), 'val_patients': sorted(val), 'test_patients': sorted(test), 'summary': summary.to_dict(orient='records')}
    (out.parent / (out.stem + '_summary.json')).write_text(json.dumps(meta, indent=2))
    print(json.dumps(meta, indent=2))
    print(f'Saved patient manifest: {out}')

if __name__ == '__main__':
    main()
