from pathlib import Path
import argparse
import pandas as pd
import yaml

CONFIGS = [
    "configs/v60_ablation_exp1_ce_baseline.yaml",
    "configs/v60_ablation_exp2_focal_fixed.yaml",
    "configs/v60_ablation_exp3_adaptive_gamma.yaml",
    "configs/v60_ablation_exp4_adaptive_gamma_ema.yaml",
    "configs/v60_ablation_exp5_full_sensitivity.yaml",
]
NAMES = [
    "Exp1-CE-Baseline",
    "Exp2-Focal-Fixed",
    "Exp3-Adaptive-Gamma",
    "Exp4-Adaptive-Gamma+EMA",
    "Exp5-Full-Sensitivity",
]

def _cfg_out_dir(cfg_path):
    cfg = yaml.safe_load(Path(cfg_path).read_text())
    return Path(cfg.get("out_dir", "runs/unknown"))

def read_best(run_dir: Path):
    hist = run_dir / "training_history.csv"
    if not hist.exists():
        return {}
    df = pd.read_csv(hist)
    if df.empty:
        return {}
    key = "val_f1" if "val_f1" in df.columns else "f1"
    idx = df[key].fillna(-1).astype(float).idxmax()
    row = df.loc[idx].to_dict()
    return {f"best_{k}": v for k, v in row.items()}

def read_test(run_dir: Path):
    p = run_dir / "test_metrics.csv"
    if not p.exists():
        return {}
    df = pd.read_csv(p)
    if df.empty:
        return {}
    return {f"test_{k}": v for k, v in df.iloc[0].to_dict().items()}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="outputs/v60_ablation_summary.csv")
    args = ap.parse_args()
    rows = []
    for name, cfg_path in zip(NAMES, CONFIGS):
        run_dir = _cfg_out_dir(cfg_path)
        row = {
            "experiment": name,
            "config": cfg_path,
            "run_dir": str(run_dir),
            "finished": (run_dir / "test_metrics.csv").exists(),
        }
        row.update(read_best(run_dir))
        row.update(read_test(run_dir))
        rows.append(row)
    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(out, index=False)
    print(df.to_string(index=False))
    print(f"Saved {out}")

if __name__ == "__main__":
    main()
