from pathlib import Path
import argparse, json
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cache-dir', '--cache_dir', dest='cache_dir', default='data/EEG_FPN_Cache_v4')
    args = ap.parse_args()
    cache = Path(args.cache_dir)
    manifest = cache / 'manifest.csv'
    print('Cache directory:', cache.resolve())
    if not manifest.exists():
        raise FileNotFoundError(f'Missing manifest.csv: {manifest}\nPut EEG_FPN_Cache_v4 under data/ or edit the config cache_dir path.')
    df = pd.read_csv(manifest)
    print('manifest rows:', len(df))
    print('columns:', list(df.columns))
    if 'split' in df.columns:
        print('splits:')
        print(df['split'].value_counts().to_string())
    if 'label' in df.columns:
        print('labels:')
        print(df['label'].value_counts().sort_index().to_string())
    files = list(cache.rglob('*.npz'))
    print('npz files:', len(files))
    meta = cache / 'cache_meta.json'
    if meta.exists():
        try:
            print('cache_meta:', json.dumps(json.loads(meta.read_text()), indent=2)[:1000])
        except Exception:
            print('cache_meta exists')
    print('OK: cache is readable')

if __name__ == '__main__':
    main()
