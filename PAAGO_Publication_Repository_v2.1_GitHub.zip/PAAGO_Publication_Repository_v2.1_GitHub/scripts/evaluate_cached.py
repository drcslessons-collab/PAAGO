import argparse, yaml, torch, json
from pathlib import Path
from torch.utils.data import DataLoader
from datasets.cached_dataset import CHBMITCachedDataset
from models.eeg_fpn import EEGFPN
from trainer.engine import run_epoch
from evaluation.metrics import save_metrics_csv


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--split', default='test', choices=['train','val','test'])
    ap.add_argument('--out', default=None)
    ap.add_argument('--manifest-name', default=None)
    ap.add_argument('--threshold', default='best')
    args = ap.parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ck = torch.load(args.checkpoint, map_location=device)
    cfg = ck.get('cfg', {})
    cache_dir = cfg.get('cache_dir', 'data/EEG_FPN_Cache_v4')
    ds = CHBMITCachedDataset(cache_dir, args.split, sort_by_chunk=True, manifest_name=(args.manifest_name or cfg.get('manifest_name','manifest.csv')))
    batch_size = int(cfg.get('batch_size', 8 if device.type=='cpu' else 128))
    nw = 0 if device.type=='cpu' else int(cfg.get('num_workers', 2))
    dl = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=nw, pin_memory=(device.type=='cuda'))
    model = EEGFPN(cfg['channels'], cfg['samples'], cfg['num_classes'], **cfg['model']).to(device)
    model.load_state_dict(ck['model'])
    # v54: use EMA-smoothed weights at evaluation when available.
    if cfg.get('use_ema', False) and ck.get('ema') and ck['ema'].get('shadow'):
        shadow = ck['ema']['shadow']
        with torch.no_grad():
            for name, param in model.named_parameters():
                if name in shadow:
                    param.data.copy_(shadow[name].to(device))
        print('[ema] using EMA weights for evaluation')
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
    if args.threshold in ['best','auto']:
        threshold = float(ck.get('best_threshold', cfg.get('threshold', 0.5)))
    else:
        threshold = float(args.threshold)
    m, y, p = run_epoch(model, dl, opt, device, None, False, cfg.get('lambda_cls',1.0), cfg.get('lambda_risk',0.1), None,
                        threshold=threshold, loss_type=cfg.get('loss_type','stable_focal'),
                        focal_gamma=cfg.get('focal_gamma',1.5), optimize_threshold=False)
    out = Path(args.out) if args.out else Path(cfg.get('out_dir','runs/evaluation')) / f'{args.split}_metrics_cached.csv'
    out.parent.mkdir(parents=True, exist_ok=True)
    save_metrics_csv(m, out)
    print(json.dumps(m, indent=2))
    print('saved:', out)

if __name__ == '__main__':
    main()
