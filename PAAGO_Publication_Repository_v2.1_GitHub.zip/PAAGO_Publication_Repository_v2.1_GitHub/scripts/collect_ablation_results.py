import argparse
from pathlib import Path
import pandas as pd

EXPS = [
    ("Exp1-CE-Baseline", "v54_ablation_exp1_ce_baseline"),
    ("Exp2-Focal-Fixed", "v54_ablation_exp2_focal_fixed"),
    ("Exp3-Adaptive-Gamma", "v54_ablation_exp3_adaptive_gamma"),
    ("Exp4-Adaptive-Gamma+EMA", "v54_ablation_exp4_adaptive_gamma_ema"),
    ("Exp5-Full-Sensitivity", "v54_ablation_exp5_full_sensitivity"),
]

def read_best_train(run_dir: Path):
    hist = run_dir / "training_history.csv"
    if not hist.exists():
        return {}
    df = pd.read_csv(hist)
    if df.empty:
        return {}
    # Prefer validation F1 when available.
    key = "val_f1" if "val_f1" in df.columns else "f1"
    idx = df[key].fillna(-1).astype(float).idxmax()
    row = df.loc[idx].to_dict()
    return {f"best_{k}": v for k, v in row.items()}

def read_test(run_dir: Path):
    p = run_dir / "test_metrics.csv"
    if not p.exists():
        return {}
    df = pd.read_csv(p)
    if df.empty:
        return {}
    return {f"test_{k}": v for k, v in df.iloc[0].to_dict().items()}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", default="outputs/v54_ablation_summary.csv")
    args = ap.parse_args()
    runs = Path(args.runs)
    rows = []
    for name, folder in EXPS:
        run_dir = runs / folder
        row = {"experiment": name, "run_dir": str(run_dir), "finished": (run_dir / "test_metrics.csv").exists()}
        row.update(read_best_train(run_dir))
        row.update(read_test(run_dir))
        rows.append(row)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(out, index=False)
    print(df.to_string(index=False))
    print(f"Saved {out}")

if __name__ == "__main__":
    main()
