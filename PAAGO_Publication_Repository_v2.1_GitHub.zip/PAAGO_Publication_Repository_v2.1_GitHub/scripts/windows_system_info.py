import os, platform
try:
    import psutil
except Exception:
    psutil = None
print('Python:', platform.python_version())
print('Platform:', platform.platform())
print('Processor:', platform.processor())
print('CPU count:', os.cpu_count())
if psutil:
    vm = psutil.virtual_memory()
    print('RAM total GB:', round(vm.total/1024**3,2))
    print('RAM available GB:', round(vm.available/1024**3,2))
