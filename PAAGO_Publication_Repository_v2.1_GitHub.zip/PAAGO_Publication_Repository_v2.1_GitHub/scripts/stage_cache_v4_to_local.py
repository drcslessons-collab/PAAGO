import argparse, shutil, subprocess, time
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description='Stage EEG-FPN v4 sharded cache from Drive to local scratch.')
    ap.add_argument('--src', default='/content/drive/MyDrive/EEG_FPN_Cache_v4/chbmit_cache')
    ap.add_argument('--dst', default='/content/local-scratch/chbmit_cache_v4')
    ap.add_argument('--clean', action='store_true')
    args = ap.parse_args()
    src, dst = Path(args.src), Path(args.dst)
    if not (src / 'manifest.csv').exists():
        raise FileNotFoundError(f'Missing manifest: {src}/manifest.csv')
    if args.clean and dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True, exist_ok=True)
    t0=time.time()
    try:
        subprocess.check_call(['rsync','-a','--info=progress2', str(src)+'/', str(dst)+'/'])
    except Exception:
        shutil.copytree(src, dst, dirs_exist_ok=True)
    print(f'Done in {(time.time()-t0)/60:.1f} min')
    print('files:', sum(1 for p in dst.rglob('*') if p.is_file()))
    print('size check: run !du -sh', dst)

if __name__ == '__main__':
    main()
