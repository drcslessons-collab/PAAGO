
import argparse, re
from pathlib import Path
import pandas as pd
import numpy as np

try:
    from scipy.stats import wilcoxon
except Exception:
    wilcoxon = None

METRICS = ['f1','sensitivity','specificity','roc_auc','pr_auc','balanced_accuracy','mcc','precision','accuracy']

def read_test_metrics(run_dir):
    p = Path(run_dir) / 'test_metrics.csv'
    if not p.exists():
        return None
    df = pd.read_csv(p)
    if df.empty:
        return None
    row = df.iloc[0].to_dict()
    return row

def read_best_val(run_dir):
    p = Path(run_dir) / 'training_history.csv'
    if not p.exists():
        return {}
    df = pd.read_csv(p)
    if df.empty or 'val_f1' not in df.columns:
        return {}
    idx = df['val_f1'].fillna(-1).astype(float).idxmax()
    row = df.loc[idx].to_dict()
    return {
        'best_epoch': int(row.get('epoch', idx+1)),
        'best_val_f1': float(row.get('val_f1', np.nan)),
        'best_val_sensitivity': float(row.get('val_sensitivity', np.nan)),
        'best_val_specificity': float(row.get('val_specificity', np.nan)),
        'best_val_roc_auc': float(row.get('val_roc_auc', np.nan)),
        'best_val_pr_auc': float(row.get('val_pr_auc', np.nan)),
        'best_val_threshold': float(row.get('val_threshold', np.nan)),
    }

def parse_run_name(name):
    # v62_exp5_full_sensitivity_seed42
    m = re.match(r'v62_(.+)_seed(\d+)$', name)
    if not m:
        return None, None
    return m.group(1), int(m.group(2))

def mean_std(series):
    vals = pd.to_numeric(series, errors='coerce').dropna().values
    if len(vals)==0:
        return '', ''
    return float(np.mean(vals)), float(np.std(vals, ddof=1)) if len(vals)>1 else 0.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--runs', default='runs')
    ap.add_argument('--out', default='outputs')
    ap.add_argument('--baseline', default='exp1_ce_baseline')
    args = ap.parse_args()
    runs = Path(args.runs)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    rows=[]
    for d in sorted(runs.glob('v62_*_seed*')):
        if not d.is_dir(): continue
        exp, seed = parse_run_name(d.name)
        if exp is None: continue
        tm = read_test_metrics(d)
        if tm is None: continue
        r = {'experiment': exp, 'seed': seed, 'run_dir': str(d)}
        r.update(read_best_val(d))
        for k,v in tm.items():
            r[f'test_{k}'] = v
        rows.append(r)
    raw = pd.DataFrame(rows)
    raw.to_csv(out/'v62_best_runs.csv', index=False)
    if raw.empty:
        print('[collect] no completed v62 runs found')
        return
    # Summary table
    summary=[]
    for exp, g in raw.groupby('experiment'):
        row={'experiment': exp, 'n_seeds': len(g)}
        for m in METRICS:
            col = f'test_{m}'
            if col in g.columns:
                mu, sd = mean_std(g[col])
                row[f'{m}_mean'] = mu
                row[f'{m}_std'] = sd
                row[f'{m}_mean_std'] = '' if mu=='' else f'{mu:.4f} ± {sd:.4f}'
        summary.append(row)
    summary = pd.DataFrame(summary).sort_values('experiment')
    summary.to_csv(out/'v62_ablation_summary.csv', index=False)
    # Statistical comparison vs baseline on paired seeds
    stats=[]
    base = raw[raw.experiment == args.baseline]
    for exp, g in raw.groupby('experiment'):
        if exp == args.baseline: continue
        row={'baseline':args.baseline, 'experiment':exp}
        for m in ['test_f1','test_sensitivity','test_roc_auc','test_pr_auc','test_mcc']:
            if m not in raw.columns: continue
            pairs = pd.merge(base[['seed',m]], g[['seed',m]], on='seed', suffixes=('_baseline','_exp'))
            if len(pairs) >= 2:
                diff = pairs[f'{m}_exp'] - pairs[f'{m}_baseline']
                row[m+'_mean_delta'] = float(diff.mean())
                if wilcoxon is not None and len(pairs) >= 3 and not np.allclose(diff, 0):
                    try:
                        row[m+'_wilcoxon_p'] = float(wilcoxon(pairs[f'{m}_baseline'], pairs[f'{m}_exp']).pvalue)
                    except Exception:
                        row[m+'_wilcoxon_p'] = np.nan
                else:
                    row[m+'_wilcoxon_p'] = np.nan
            else:
                row[m+'_mean_delta'] = np.nan; row[m+'_wilcoxon_p']=np.nan
        stats.append(row)
    pd.DataFrame(stats).to_csv(out/'v62_ablation_stats.csv', index=False)
    print('[collect] saved:')
    print(' ', out/'v62_best_runs.csv')
    print(' ', out/'v62_ablation_summary.csv')
    print(' ', out/'v62_ablation_stats.csv')

if __name__ == '__main__':
    main()
